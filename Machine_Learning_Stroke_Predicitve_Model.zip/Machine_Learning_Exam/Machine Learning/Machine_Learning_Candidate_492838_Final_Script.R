
# Machine Learning Assignment Candidate 492838

# ========================================================
# OBJECTIVE: Develop predictive models for post-stroke mortality
# using 22 baseline variables. Focus on model performance and
# feature importance without clinical interpretation.
# ========================================================
# -------------------- SETUP AND DATA PREPARATION --------------------
# Install and load required packages for:
# - Data manipulation (tidyverse, dplyr)
# - Visualisation (ggplot2, ggcorrplot, GGally)
# - Machine learning (glmnet, mboost, xgboost, randomForest)
# - Model evaluation (caret, pROC)
# - Class imbalance handling (smotefamily)


# Install required packages if not already installed
install.packages("mboost")    # For gradient boosting
install.packages("smotefamily")  # For handling imbalanced datasets
install.packages("GGally")    # For advanced plotting and visualisation
install.packages("ggcorrplot") # For correlation matrix visualisation
install.packages("xgboost")   # For extreme gradient boosting

# Data manipulation and preprocessing
library(tidyverse)  # Collection of data manipulation packages
library(dplyr)      # For data wrangling
library(forcats)    # For factor variable manipulation

# Visualisation
library(ggplot2)    # For creating static graphics
library(ggcorrplot) # For correlation matrix visualisation
library(GGally)     # For pair plots and extended ggplot2 functionality
library(gridExtra)  # For arranging multiple plots

#These libraries will produce several warning messages

# Machine Learning and Modeling
library(glmnet)     # For regularised regression (LASSO, Ridge, Elastic Net)
library(mboost)     # For gradient boosting
library(xgboost)    # For extreme gradient boosting
library(randomForest) # For traditional random forests
library(ranger)     # For fast random forest implementation

#These libraries will produce several warning messages

# Model Training and Evaluation
library(caret)      # For model training, validation and preprocessing
library(pROC)       # For ROC curve analysis and visualisation

#These libraries will produce several warning messages

# Data Balancing
library(smotefamily) # For handling class imbalance using SMOTE variants

#This library will produce several warning messages

# -------------------- DATA PREPROCESSING --------------------
# 1. Read and inspect the dataset
# 2. Handle missing values (none present in this case)
# 3. Convert death outcome to factor (Survived/Died)
# 4. Convert categorical variables to factors
# This ensures proper data structure for modeling

# Read in the dataset. Empty rows are ommitted by default
setwd("~/Machine Learning")
library(readr)
data <- read_csv("assignment2025.csv")
View(assignment2025)
summary(data)
# View the first rows
head(data)

# Check for missing values
sum(is.na(data)) # no missing values

# Outcome factor of death and survived is converted to factor to ensure quanititative data
data$death <- factor(data$death, levels = c(0, 1), labels = c("Survived", "Died"))

# Factorise the categorical variables
categorical_columns <- names(data)[sapply(data, function(x) is.character(x) | is.factor(x))]
categorical_columns <- setdiff(categorical_columns, 'death')
data[categorical_columns] <- lapply(data[categorical_columns], factor)


#Now with changes categorical variables alongside death etc
summary(data)

# Explore death rate by subtype
death_rate <- data %>%
  group_by(subtype) %>%
  summarise(drate = mean(as.numeric(death)-1) * 100)

# -------------------- EXPLORATORY DATA ANALYSIS --------------------
# Key visualisations and summaries:

# 1. Stroke Subtype Analysis
# - Created bar chart showing mortality rates across different stroke subtypes
# - Used ordered factor levels to display subtypes from lowest to highest mortality
# - Visualization uses a soft blue color scheme for better readability

# 2. Overall Mortality Distribution
# - Created bar chart showing the binary outcome (survived vs deceased)
# - Added percentage labels directly on bars for quick interpretation
# - Color-coded: Green for survivors, Red for deceased
# - Includes actual counts and percentages for each outcome

# 3. Categorical Variable Analysis
# - Generated summary statistics for all categorical variables by outcome
# - Excluded symptom variables from initial categorical analysis
# - Created two summary tables:
#   a. One showing counts with percentages in parentheses
#   b. Another showing raw counts split by survival status

# 4. Treatment Outcome Analysis
# - Treatment 1: 3,114 survived, 153 deceased
# - Treatment 2: 6,251 survived, 293 deceased
# - Used dodged bar chart to compare outcomes between treatments
# - Both treatments show similar survival-to-mortality ratios
# - Added direct value labels on bars for easy comparison

ggplot(death_rate, aes(x = fct_reorder(subtype, drate), y = drate)) +
  geom_bar(stat = "identity", fill = "orange", color = "black") +  # Changed to a softer blue
  labs(x = "Stroke Subtype", y = "Mortality Rate (%)", title = "Mortality Rate by Stroke Subtype") +
  theme_minimal() +
  theme_bw()

# Calculate percentages first
outcome_summary <- data %>%
  count(death) %>%
  mutate(percentage = n/sum(n) * 100)

# Create bar plot with percentages
ggplot(data, aes(x = factor(death))) +
  geom_bar(fill = c("#4CAF50", "#F44336")) +  # Green for survived, Red for deceased
  geom_text(data = outcome_summary,
            aes(x = death, y = n, label = sprintf("%.1f%%", percentage)),
            position = position_stack(vjust = 0.5),
            color = "white",
            size = 4) +
  labs(title = "Patient Outcome Distribution",
       x = "Outcome (0 = Survived, 1 = Deceased)",
       y = "Number of Patients") +
  theme_minimal() +
  scale_x_discrete(labels = c("Survived", "Deceased"))

# Summary calculation
cat_summary <- data %>%
  select(all_of(categorical_columns), death) %>%
  select(-starts_with("symptom")) %>%
  group_by(death) %>%
  summarise(across(everything(), ~sum(. == levels(.)[2]))) %>%
  pivot_longer(-death, names_to = "Variable", values_to = "Count") %>%
  pivot_wider(names_from = death, values_from = Count)
colnames(cat_summary) <- c("Variable", "Survived", "Deceased")
print(cat_summary)

# Create dataframe for treatments only to show how many died and survived in each treatment arm
treatment_data <- data.frame(
  Variable = c("treat1", "treat2"),
  Survived = c(3114, 6251),
  Deceased = c(153, 293)
)

# Convert to long format for plotting
treatment_long <- treatment_data %>%
  pivot_longer(cols = c(Survived, Deceased),
               names_to = "Outcome",
               values_to = "Count")

# Create the bar chart with improved spacing
ggplot(treatment_long, aes(x = Variable, y = Count, fill = Outcome)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("Deceased" = "#F44336", "Survived" = "#4CAF50")) +
  labs(title = "Treatment Outcomes",
       x = "Treatment Type",
       y = "Number of Patients",
       fill = "Outcome") +
  scale_x_discrete(labels = c("Treatment 1", "Treatment 2")) +
  # Expand y-axis limits to make room for labels
  scale_y_continuous(limits = c(0, 7000)) +  # Adjusted fixed limits
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.text = element_text(size = 10),
    legend.position = "right",
    plot.spacing = unit(2, "lines")  # Add spacing between plot elements
  ) +
  # Add value labels on the bars
  geom_text(aes(label = Count),
            position = position_dodge(width = 0.9),
            vjust = -0.5,
            size = 4)

# Stacked bar plot for symptom variables by death outcome
symptom_vars <- grep("^symptom", names(data), value = TRUE)
symptom_death <- data %>%
  pivot_longer(cols = all_of(symptom_vars), names_to = "Symptom", values_to = "Present") %>%
  filter(Present == "Y") %>%
  group_by(Symptom) %>%
  summarise(DeathRate = mean(death == "Died") * 100)

# Extract numbers from symptom names and add as a new column
symptom_death <- symptom_death %>%
  mutate(SymptomNumber = as.numeric(str_extract(Symptom, "\\d+")))

# Create the plot
ggplot(symptom_death, aes(x = SymptomNumber, y = DeathRate, fill = DeathRate)) +
  geom_col() +
  labs(title = "Mortality Rate by Symptom", 
       x = "Symptom Number", 
       y = "Mortality Rate (%)") +
  scale_fill_gradient(low = "#AED6F1", high = "#C0392B",  # Softer blue to dark red gradient
                      name = "Mortality Rate (%)") +
  scale_x_continuous(breaks = symptom_death$SymptomNumber) +  # Show all symptom numbers
  theme_minimal() +
  theme(
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 12),
    title = element_text(size = 14)
  )

# ========================================
# Create training and validation datasets
# ========================================

# Using create DataPartition to maintain balanced mortality distribution
validation_proportion <- 0.2  # 80% training, 20% validation split
set.seed(50)  # Set random seed for reproducibility
validation_indices <- createDataPartition(y = data$death, p = validation_proportion)[[1]]

# Separate into training and validation sets
train_data <- data[-validation_indices,]
validation_data <- data[validation_indices,]

train_org <- data[-validation_indices,]
test_org <-data[validation_indices,]
# Maintain original class distribution in validation set
# This preserves the natural mortality rate for realistic evaluation
# Convert data to matrix format for model input
X_train <- model.matrix(death ~ . - 1, train_data)
y_train <- train_data$death
X_validation <- model.matrix(death ~ . - 1, validation_data)
y_validation <- validation_data$death

# Create balanced dataset for model training
set.seed(50)  # ensure consistentcy 
train_data_balanced <- upSample(x = train_data[, -which(names(train_data) == "death")], 
                                y = train_data$death) %>%
  rename(death = Class)

# Scale continuous variables
continuous_vars <- c("age", "delay", "sbp")
preProc <- preProcess(train_data_balanced[, continuous_vars], method = c("center", "scale"))
train_data_balanced[, continuous_vars] <- predict(preProc, train_data_balanced[, continuous_vars])

# Create matrix format for balanced data
X_train_balanced <- model.matrix(death ~ . - 1, train_data_balanced)
y_train_balanced <- train_data_balanced$death

# ============================================
# Section 2: Penalised Logistic Regression
# ============================================

# Use glmnet to create a ridge regression model
ridge_model <- cv.glmnet(X_train, y_train,
                         family = "binomial",
                         alpha = 0) # Ridge regression

# Adjust margins to prevent title overlap for Ridge plot
par(mar = c(5, 4, 6, 2) + 0.1)  # Increases top margin
# Plot the binomial deviance for different values of lambda
plot(ridge_model, main = "Ridge Model Optimisation")


# Train a lasso model with alpha = 1 (default)
lasso_model <- cv.glmnet(X_train, y_train,
                         family = "binomial")
# Adjust margins to prevent title overlap for Lasso plot
par(mar = c(5, 4, 6, 2) + 0.1)  # Increases top margin
plot(lasso_model, main = "Lasso Optimisation")

# Train an elastic net model with alpha in [0,1]
elastic_net_model <- train(death ~ .,
                           data = train_data,
                           method = "glmnet", 
                           family = "binomial",
                           tuneGrid = expand.grid(alpha = 0:10 / 10, 
                                                  lambda = 10^seq(-5, 2, length.out = 100)),
                           trControl = trainControl("cv",
                                                    number = 10,
                                                    summaryFunction = twoClassSummary,
                                                    classProbs = TRUE),
                           metric = "ROC")


# Plot the ROC for elastic net model
plot(elastic_net_model, xTrans = log10)

# For Ridge model
ridge_coefs <- coef(ridge_model, s = ridge_model$lambda.min)
ridge_nonzero <- sum(ridge_coefs != 0) - 1  # Subtract 1 to exclude intercept
cat("Number of features in Ridge model:", ridge_nonzero, "\n")

# Display optimal hyperparameters found during training
cat("Ridge lambda minimum:\n")
print(ridge_model$lambda.min)

# For Lasso model
lasso_coefs <- coef(lasso_model, s = lasso_model$lambda.min)
lasso_nonzero <- sum(lasso_coefs != 0) - 1  # Subtract 1 to exclude intercept
cat("Number of features in Lasso model:", lasso_nonzero, "\n")

cat("\nLasso model parameters:\n")
cat("Lambda minimum:\n")
print(lasso_model$lambda.min)

cat("\nLambda 1se:\n")
print(lasso_model$lambda.1se)

#Elastic Net

cat("\nElastic Net best parameters:\n")
print(elastic_net_model$bestTune)


#--------------- Future Exploratory Analysis Notes ---------------
# Further analysis could explore Balanced Elastic Net approach:
# - Initial testing showed lower performance (AUC: 0.798, Sensitivity: 0.702)
# - Could be revisited if specificity becomes more critical
# - Implementation would use below configuration:


# ============ MODEL TRAINING ============

# ============ RANDOM FOREST IMPLEMENTATION ============
# Justification: Initially chosen for ability to capture non-linear relationships and interactions

# ============ DATA INSPECTION ============
# Check dimensions and structure of training data

dim(train_data)
head(train_data)
# Verify response variable type and distribution 
class(train_data$death)
table(train_data$death)

# ============ INITIAL RANDOM FOREST MODEL ============
# Basic random forest with default parameters
# simple_rf <- randomForest(death ~ ., 
#                          data = train_data,
#                          ntree = 100)
# print(simple_rf)

# ============ SIMPLIFIED TUNING VERSION ============
# Attempt with basic parameter tuning
# rf_model_simple <- train(death ~ ., 
#                         data = train_data,
#                         method = "ranger",
#                         num.trees = 100,
#                         tuneGrid = expand.grid(
#                           mtry = c(2, 4),
#                           min.node.size = c(1),
#                           splitrule = "gini"
#                         ),
#                         trControl = trainControl(
#                           method = "cv",
#                           number = 5,
#                           sampling = "down",
#                           classProbs = TRUE,
#                           summaryFunction = twoClassSummary
#                         ),
#                         metric = "ROC")
# print(rf_model_simple)

# ============ FULL MODEL WITH EXTENSIVE TUNING ============
# Calculate number of predictors for parameter grid
# n_predictors <- ncol(train_data) - 1  # subtract 1 for response variable
# mtry_values <- seq(2, min(n_predictors, 20), by = 2)  # cap at 20 for computational efficiency

# Full model with comprehensive parameter tuning
# rf_model <- train(death ~ ., 
#                   data = train_data,
#                   method = "ranger",
#                   num.trees = 500,
#                   tuneGrid = expand.grid(
#                     mtry = mtry_values,
#                     min.node.size = c(1, 3, 5),
#                     splitrule = c("gini", "extratrees")
#                   ),
#                   trControl = trainControl(
#                     method = "cv",
#                     number = 10,
#                     sampling = "down",
#                     classProbs = TRUE,
#                     summaryFunction = twoClassSummary,
#                     verboseIter = TRUE
#                   ),
#                   metric = "ROC",
#                   importance = "impurity")
# print(rf_model)

# ============ MODEL EVALUATION ============
# Generate predictions
# predictions <- predict(rf_model)
# pred_probs <- predict(rf_model, type = "prob")

# ROC and AUC calculation
# library(pROC)
# roc_obj <- roc(rf_model$trainingData$.outcome, pred_probs[,"Survived"])
# auc <- auc(roc_obj)
# optimal_threshold <- coords(roc_obj, "best", best.method = "youden")

# Performance metrics calculation
# library(caret)
# cm <- confusionMatrix(predictions, rf_model$trainingData$.outcome)
# print(cm)

# ============ SMOTE ATTEMPT ============
# Install and load SMOTE package
# install.packages("DMwR2")
# library(DMwR2)

# Model with SMOTE sampling
# rf_model_smote <- train(death ~ ., 
#                         data = train_data,
#                         method = "ranger",
#                         num.trees = 500,
#                         tuneGrid = expand.grid(
#                           mtry = mtry_values,
#                           min.node.size = c(1, 3, 5),
#                           splitrule = c("gini", "extratrees")
#                         ),
#                         trControl = trainControl(
#                           method = "cv",
#                           number = 10,
#                           sampling = "smote",
#                           classProbs = TRUE,
#                           summaryFunction = twoClassSummary,
#                           verboseIter = TRUE
#                         ),
#                         metric = "ROC",
#                         importance = "impurity")

# ============ ROSE ATTEMPT (UNSUCCESSFUL) ============
# Load required packages
# library(caret)
# library(ranger)
# library(ROSE)

# ============ ADASYN ATTEMPT ============
# Install and load ADASYN package
# install.packages("smotefamily")
# library(smotefamily)

# Prepare numeric data for ADASYN
# train_data_numeric <- train_data
# categorical_cols <- sapply(train_data, is.factor)
# for(col in names(train_data)[categorical_cols]) {
#   train_data_numeric[[col]] <- as.numeric(train_data_numeric[[col]])
# }

# Apply ADASYN balancing
# adas <- ADAS(X = train_data_numeric[,-which(names(train_data_numeric) == "death")], 
#              target = train_data_numeric$death, 
#              K = 5)

# Prepare balanced dataset
# balanced_data_adas <- data.frame(adas$data)
# names(balanced_data_adas)[ncol(balanced_data_adas)] <- "death"
# balanced_data_adas$death <- factor(balanced_data_adas$death, 
#                                    levels = c(1, 2),
#                                    labels = c("survived", "died"))

# Check class balance after ADASYN
# table(balanced_data_adas$death)

# Train model with ADASYN balanced data
# rf_model_adas <- train(death ~ ., 
#                        data = balanced_data_adas,
#                        method = "ranger",
#                        num.trees = 500,
#                        tuneGrid = expand.grid(
#                          mtry = c(2, 4, 6, 8),
#                          min.node.size = c(1, 3),
#                          splitrule = "gini"
#                        ),
#                        trControl = trainControl(
#                          method = "cv",
#                          number = 5,
#                          classProbs = TRUE,
#                          summaryFunction = twoClassSummary
#                        ),
#                        metric = "ROC",
#                        importance = "impurity")

# print(rf_model_adas)

# ============ CONCLUSION ============
# Multiple attempts with Random Forest showed signs of overfitting:
# - Poor specificity and sensitivity despite various sampling techniques
# - ROSE sampling proved incompatible with the implementation
# - SMOTE and ADASYN did not sufficiently improve model performance
# 
# Next steps: Consider boosting algorithms (XGBoost) for:
# - Better handling of class imbalance
# - Built-in regularisation
# - Potential for improved generalisation

# ============================================
# Section 3: XGBoost Implementation
# ============================================
#--------------- Basic XGBoost Model ---------------

# Helper function to prepare XGBoost data matrices
# Converts features and response to required format
prepare_basic_xgb_data <- function(X_data, y_data) {
  # Convert target to numeric (Died = 1, Survived = 0)
  labels <- as.numeric(y_data == "Died")
  # Create and return XGBoost DMatrix
  xgb.DMatrix(data = X_data, label = labels)
}

# Create XGBoost matrices for different data splits
xgtrain <- prepare_basic_xgb_data(X_train, y_train)
xgtest <- prepare_basic_xgb_data(X_validation, y_validation)
xgtrain_balanced <- prepare_basic_xgb_data(X_train_balanced, y_train_balanced)

# Define basic model parameters
xgboost_params <- list(
  objective = "binary:logistic",  # Binary classification task
  eval_metric = "auc"            # Area Under Curve metric
)

# Perform k-fold cross-validation
xgboost_cv <- xgb.cv(
  params = xgboost_params,      # Model parameters
  data = xgtrain,              # Training data
  nrounds = 500,               # Maximum boosting rounds
  nfold = 10,                  # Number of CV folds
  verbose = FALSE              # Suppress training messages
)

# Extract optimal performance metrics
optimal_rounds <- which.max(xgboost_cv$evaluation_log$test_auc_mean)
best_auc <- max(xgboost_cv$evaluation_log$test_auc_mean)

# Create visualization of cross-validation results
ggplot(xgboost_cv$evaluation_log, aes(x = iter, y = test_auc_mean)) +
  geom_line(color = "darkred") +     # Line connecting points
  geom_point(size = 1) +             # Points for each iteration
  geom_vline(                        # Vertical line at optimal rounds
    xintercept = optimal_rounds, 
    linetype = "dashed"
  ) +
  labs(                              # Plot labels
    title = "XGBoost Model Performance Across Iterations",
    x = "Iteration",
    y = "Test AUC"
  ) +
  theme_minimal()                     # Clean theme

# Train final model using optimal number of rounds
xgboost_model <- xgb.train(
  params = xgboost_params,          # Model parameters
  data = xgtrain,                   # Full training dataset
  nrounds = optimal_rounds          # Optimal number of rounds from CV
)
# ============================================
# Advanced XGBoost Model with Tuned Parameters
# ============================================

#--------------- Advanced XGBoost Model with Balanced Data ---------------

# Helper function to prepare data for XGBoost
# Converts input data frame to matrix format and creates XGBoost DMatrix object
prepare_xgb_data <- function(data) {
  # Create design matrix, removing intercept (-1)
  matrix_data <- model.matrix(death ~ . - 1, data)
  
  # Convert death outcome to binary numeric (Died = 1, Survived = 0)
  labels <- as.numeric(data$death == "Died")
  
  # Return both regular matrix and XGBoost's specialized DMatrix format
  list(
    matrix = matrix_data,
    dmatrix = xgb.DMatrix(data = matrix_data, label = labels)
  )
}

# Convert balanced training data to XGBoost format
#train_data <- prepare_xgb_data(train_data_balanced)
X_train_original <- model.matrix(death ~ . - 1, train_org)
y_train_original <- train_org$death

# Calculate appropriate scale_pos_weight for class imbalance
scale_pos_weight <- sum(y_train_original == "Survived") / sum(y_train_original == "Died")

# Convert to optimized DMatrix format
dtrain <- xgb.DMatrix(
  data = X_train_original,
  label = as.numeric(y_train_original == "Died")
)

# Define hyperparameters for advanced XGBoost model
# Define hyperparameters for advanced XGBoost model
advanced_params <-list(
  objective = "binary:logistic",
  eval_metric = "auc",
  eta = 0.1,                 # Increased learning rate
  max_depth = 6,             # Deeper trees for complex patterns
  min_child_weight = 2,       # Balanced node splitting
  subsample = 0.8,            # Prevent overfitting
  colsample_bytree = 0.8,     # Feature diversity
  gamma = 0.2,                # Regularization of node splits
  lambda = 0.5,               # L2 regularization
  alpha = 0.1,                # L1 regularization
  scale_pos_weight = scale_pos_weight # Handle class imbalance
)

# Perform k-fold cross-validation
set.seed(50)                        # Set seed for reproducibility
cv_results <- xgb.cv(
  params = advanced_params,
  data = dtrain,
  nrounds = 1000,
  nfold = 5,
  early_stopping_rounds = 30,
  verbose = 1
)
# Find the optimal number of rounds from cross-validation
optimal_rounds <- cv_results$best_iteration

# Train final model using optimal number of rounds
xgboost_model_advanced <- xgb.train(
  params = advanced_params,
  data = dtrain,
  nrounds = optimal_rounds,
  watchlist = list(train = dtrain),
  verbose = 1
)

# Create visualization of cross-validation results
ggplot(cv_results$evaluation_log, aes(x = iter, y = test_auc_mean)) +
  geom_line(color = "darkred") +    # Line connecting points
  geom_point(size = 1) +            # Points for each iteration
  geom_vline(                       # Vertical line at optimal rounds
    xintercept = optimal_rounds, 
    linetype = "dashed"
  ) +
  labs(                             # Plot labels
    title = "AUC Score by Iteration",
    x = "Iteration",
    y = "Test AUC"
  ) +
  theme_minimal()                    # Clean theme for visualisation


# ============================================
# Section 4: Model Comparison
# ============================================
# Calculate model performance metrics
calculate_metrics <- function(model_name, probabilities, actual_outcomes) {
  
  # Convert outcomes to binary format
  binary_outcomes <- as.numeric(actual_outcomes == "Died")
  
  # Ensure probabilities are in vector format
  probabilities <- as.vector(probabilities)
  
  # Compute ROC curve and AUC
  roc_analysis <- roc(binary_outcomes, probabilities)
  auc_value <- auc(roc_analysis)
  
  # Find optimal classification threshold using Youden's Index
  optimal_index <- which.max(roc_analysis$sensitivities + roc_analysis$specificities - 1)
  optimal_threshold <- roc_analysis$thresholds[optimal_index]
  
  # Create predicted class labels
  predicted_classes <- factor(ifelse(probabilities > optimal_threshold, "Died", "Survived"), 
                              levels = c("Survived", "Died"))
  
  # Generate confusion matrix
  confusion_stats <- confusionMatrix(predicted_classes, actual_outcomes)
  
  # Calculate performance metrics
  precision_score <- confusion_stats$byClass["Precision"]
  recall_score <- confusion_stats$byClass["Sensitivity"]
  f1_value <- 2 * (precision_score * recall_score) / (precision_score + recall_score)
  
  # Calculate balanced accuracy
  balanced_acc <- (confusion_stats$byClass["Sensitivity"] + confusion_stats$byClass["Specificity"]) / 2
  
  # Compile all metrics
  performance_metrics <- list(
    model = model_name,
    auc = auc_value,
    sensitivity = confusion_stats$byClass["Sensitivity"],
    specificity = confusion_stats$byClass["Specificity"],
    f1_score = f1_value,
    balanced_accuracy = balanced_acc,
    threshold = optimal_threshold
  )
  
  return(performance_metrics)
}

# Generate prediction probabilities
ridge_predictions <- predict(ridge_model, newx = X_validation, type = "response")
lasso_predictions <- predict(lasso_model, newx = X_validation, type = "response")
elastic_net_predictions <- predict(elastic_net_model, newdata = validation_data, type = "prob")[,"Died"]
xgboost_predictions <- predict(xgboost_model, xgb.DMatrix(X_validation))
xgboost_advanced_predictions <- predict(xgboost_model_advanced, xgb.DMatrix(X_validation))

# Calculate performance metrics for each model
ridge_performance <- calculate_metrics("Ridge", ridge_predictions, y_validation)
lasso_performance <- calculate_metrics("Lasso", lasso_predictions, y_validation)
elastic_net_performance <- calculate_metrics("Elastic Net", elastic_net_predictions, y_validation)
xgboost_performance <- calculate_metrics("XGBoost", xgboost_predictions, y_validation)
xgboost_advanced_performance <- calculate_metrics("Advanced XGBoost", xgboost_advanced_predictions, y_validation)

# Combine all model performances
model_performances <- list(ridge_performance, lasso_performance, elastic_net_performance, 
                           xgboost_performance, xgboost_advanced_performance)

# Create comparison table
model_comparison <- data.frame(
  Model = c("Ridge", "Lasso", "Elastic Net", "XGBoost", "Advanced XGBoost"),
  AUC = sapply(model_performances, function(x) x$auc),
  Sensitivity = sapply(model_performances, function(x) x$sensitivity),
  Specificity = sapply(model_performances, function(x) x$specificity),
  F1 = sapply(model_performances, function(x) x$f1_score),
  Balanced_Acc = paste0(round(sapply(model_performances, function(x) x$balanced_accuracy) * 100, 2), "%"),
  Threshold = sapply(model_performances, function(x) x$threshold)
)

# Round numeric columns to 3 decimal places
numeric_columns <- c("AUC", "Sensitivity", "Specificity", "F1", "Threshold")
model_comparison[, numeric_columns] <- round(model_comparison[, numeric_columns], 3)

# Display results
print(model_comparison)

############################
# Model   AUC Sensitivity Specificity    F1 Balanced_Acc Threshold
#1            Ridge 0.809       0.760       0.748 0.857       75.38%     0.046
#2            Lasso 0.792       0.709       0.797 0.825       75.26%     0.042
#3      Elastic Net 0.816       0.799       0.707 0.881       75.33%     0.058
#4          XGBoost 0.774       0.792       0.659 0.876       72.53%     0.059
#5 Advanced XGBoost 0.784       0.763       0.715 0.859       73.91%     0.482


# ============================================
# Section 5: Feature Importance Analysis
# ============================================

# Extract feature importance from each model
# 1. Ridge
ridge_importance <- coef(ridge_model, s = ridge_model$lambda.min)[-1]  # intercept removed
ridge_importance <- abs(ridge_importance)  # Absolute value is taken
names(ridge_importance) <- colnames(X_train)  # Assign the feature names

# 2. Lasso
lasso_importance <- coef(lasso_model, s = lasso_model$lambda.min)[-1]
lasso_importance <- abs(lasso_importance)
names(lasso_importance) <- colnames(X_train)  # Assign the feature names

# Create top 10 features
ridge_top_10 <- sort(ridge_importance, decreasing = TRUE)[1:10]
lasso_top_10 <- sort(lasso_importance, decreasing = TRUE)[1:10]

# Create dataframes
ridge_importance_df <- data.frame(
  Feature = names(ridge_top_10),
  Importance = as.numeric(ridge_top_10)
)

lasso_importance_df <- data.frame(
  Feature = names(lasso_top_10),
  Importance = as.numeric(lasso_top_10)
)

# 3. Elastic Net
elastic_net_lambda <- elastic_net_model$bestTune$lambda
elastic_net_final <- elastic_net_model$finalModel
elastic_net_coef <- coef(elastic_net_final, s = elastic_net_lambda)
elastic_net_coef <- as.numeric(elastic_net_coef[-1])
names(elastic_net_coef) <- rownames(coef(elastic_net_final, s = elastic_net_lambda))[-1]
elastic_net_importance <- abs(elastic_net_coef)

# 4. Simple XGBoost - Feature Importance
xgboost_importance <- xgb.importance(model = xgboost_model)

# 5. Advanced XGBoost - Feature Importance
xgboost_advanced_importance <- xgb.importance(model = xgboost_model_advanced)

# Get top 10 features for each model
ridge_top_10 <- sort(ridge_importance, decreasing = TRUE)[1:10]
lasso_top_10 <- sort(lasso_importance, decreasing = TRUE)[1:10]
elastic_net_top_10 <- sort(elastic_net_importance, decreasing = TRUE)[1:10]
xgboost_top_10 <- xgboost_importance[1:10, ]
xgboost_advanced_top_10 <- xgboost_advanced_importance[1:10, ]

# Create dataframes for plotting
ridge_importance_df <- data.frame(Feature = names(ridge_top_10), Importance = ridge_top_10)
lasso_importance_df <- data.frame(Feature = names(lasso_top_10), Importance = lasso_top_10)
elastic_net_importance_df <- data.frame(Feature = names(elastic_net_top_10), Importance = elastic_net_top_10)
xgboost_importance_df <- data.frame(Feature = xgboost_top_10$Feature, Importance = xgboost_top_10$Gain)
xgboost_advanced_importance_df <- data.frame(Feature = xgboost_advanced_top_10$Feature, Importance = xgboost_advanced_top_10$Gain)

# Ridge plot - showing coefficient magnitude
ggplot(ridge_importance_df, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "green") +
  coord_flip() +
  labs(title = "Top 10 Ridge Regression Features", 
       x = "Feature", 
       y = "Coefficient Magnitude") +
  theme_minimal()

# Lasso plot - showing coefficient magnitude
ggplot(lasso_importance_df, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(title = "Top 10 Lasso Regression Features", 
       x = "Feature", 
       y = "Coefficient Magnitude") +
  theme_minimal()

# Elastic Net plot - showing coefficient magnitude
ggplot(elastic_net_importance_df, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "orange") +
  coord_flip() +
  labs(title = "Top 10 Elastic Net Regression Features", 
       x = "Feature", 
       y = "Coefficient Magnitude") +
  theme_minimal()

# Simple XGBoost plot - showing feature importance
ggplot(xgboost_importance_df, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "purple") +
  coord_flip() +
  labs(title = "Top 10 XGBoost Features", 
       x = "Feature", 
       y = "Feature Importance (Gain)") +
  theme_minimal()

# Advanced XGBoost plot - showing feature importance
ggplot(xgboost_advanced_importance_df, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "red") +
  coord_flip() +
  labs(title = "Top 10 Advanced XGBoost Features", 
       x = "Feature", 
       y = "Feature Importance (Gain)") +
  theme_minimal()
# ============================================
# Section 6: ROC Curve Analysis Used in Presentation
# ============================================

# Get predictions for each model
predictions_list <- list(
  Ridge = list(
    prob = ridge_predictions,
    label = "Ridge"
  ),
  Lasso = list(
    prob = lasso_predictions,
    label = "Lasso"
  ),
  ElasticNet = list(
    prob = elastic_net_predictions,
    label = "Elastic Net"
  ),
  XGBoost = list(
    prob = xgboost_predictions,
    label = "XGBoost"
  ),
  AdvancedXGBoost = list(
    prob = xgboost_advanced_predictions,
    label = "Advanced XGBoost"
  )
)

# Calculate ROC curves
roc_curves <- lapply(predictions_list, function(x) {
  roc(response = y_validation == "Died",
      predictor = x$prob,
      levels = c(FALSE, TRUE))
})

# Ridge ROC
plot(roc_curves$Ridge, 
     col = "green", 
     lwd = 2,
     main = "Ridge ROC Curve",
     legacy.axes = TRUE)
legend("bottomright", 
       legend = paste0("AUC = ", round(auc(roc_curves$Ridge), 3)),
       col = "green",
       lwd = 2)

# Lasso ROC
plot(roc_curves$Lasso, 
     col = "blue", 
     lwd = 2,
     main = "Lasso ROC Curve",
     legacy.axes = TRUE)
legend("bottomright", 
       legend = paste0("AUC = ", round(auc(roc_curves$Lasso), 3)),
       col = "blue",
       lwd = 2)

# Elastic Net ROC
plot(roc_curves$ElasticNet, 
     col = "orange", 
     lwd = 2,
     main = "Elastic Net ROC Curve",
     legacy.axes = TRUE)
legend("bottomright", 
       legend = paste0("AUC = ", round(auc(roc_curves$ElasticNet), 3)),
       col = "orange",
       lwd = 2)

# XGBoost ROC
plot(roc_curves$XGBoost, 
     col = "purple", 
     lwd = 2,
     main = "XGBoost ROC Curve",
     legacy.axes = TRUE)
legend("bottomright", 
       legend = paste0("AUC = ", round(auc(roc_curves$XGBoost), 3)),
       col = "purple",
       lwd = 2)

# Advanced XGBoost ROC
plot(roc_curves$AdvancedXGBoost, 
     col = "red", 
     lwd = 2,
     main = "Advanced XGBoost ROC Curve",
     legacy.axes = TRUE)
legend("bottomright", 
       legend = paste0("AUC = ", round(auc(roc_curves$AdvancedXGBoost), 3)),
       col = "red",
       lwd = 2)

# ============================================
# Section 7: Extract training and validation metrics from cross-validation results
# ============================================

# Perform cross-validation for Advanced XGBoost with anti-overfitting parameters
# Remove target column 'death' from predictors
predictor_data <- validation_data[, !names(validation_data) %in% "death"]

# Convert categorical variables to numerical using one-hot encoding
predictor_matrix <- model.matrix(~ . - 1, data = predictor_data)

# Ensure the target variable is numeric (0/1 for binary classification)
target_vector <- as.numeric(validation_data$death) 
target_vector <- ifelse(validation_data$death == "Died", 1, 0)

dtest <- xgb.DMatrix(data = predictor_matrix, label = target_vector)

# Convert balanced training data to XGBoost format
#train_data <- prepare_xgb_data(train_data_balanced)
X_train_original <- model.matrix(death ~ . - 1, train_org)
y_train_original <- train_org$death

# Calculate appropriate scale_pos_weight for class imbalance
scale_pos_weight <- sum(y_train_original == "Survived") / sum(y_train_original == "Died")

# Convert to optimized DMatrix format
dtrain <- xgb.DMatrix(
  data = X_train_original,
  label = as.numeric(y_train_original == "Died")
)

# Define hyperparameters for advanced XGBoost model
advanced_params <-list(
  objective = "binary:logistic",
  eval_metric = "auc",
  eta = 0.1,                 # Increased learning rate
  max_depth = 6,             # Deeper trees for complex patterns
  min_child_weight = 2,       # Balanced node splitting
  subsample = 0.8,            # Prevent overfitting
  colsample_bytree = 0.8,     # Feature diversity
  gamma = 0.2,                # Regularization of node splits
  lambda = 0.5,               # L2 regularization
  alpha = 0.1,                # L1 regularization
  scale_pos_weight = scale_pos_weight # Handle class imbalance
)

# Perform k-fold cross-validation
set.seed(50)                        # Set seed for reproducibility
cv_results <- xgb.cv(
  params = advanced_params,
  data = dtrain,
  nrounds = 1000,
  nfold = 5,
  early_stopping_rounds = 30,
  verbose = 1
)
 
xgboost_model_advanced <- xgb.train(
  params = advanced_params,
  data = dtrain,
  nrounds = 1000,
  nfold = 5,
  early_stopping_rounds = 30,
  watchlist = list(train = dtrain, test = dtest),
  verbose = 1
)

# Get the training and test AUC values
training_auc <- xgboost_model_advanced$evaluation_log$train_auc
training_auc
validation_auc <- xgboost_model_advanced$evaluation_log$test_auc
validation_auc
iterations <- 1:length(training_auc)
iterations
# Create plot comparing training and validation AUC
plot(iterations, training_auc,
     type = "l",
     col = "blue",
     lwd = 2,
     ylim = c(min(c(training_auc, validation_auc)), 
              max(c(training_auc, validation_auc))),
     xlab = "Iteration",
     ylab = "AUC",
     main = "Advanced XGBoost: Training vs Validation AUC")

# Add validation line
lines(iterations, validation_auc, col = "darkred", lwd = 2)

# Add optimal iteration point
optimal_iter <- which.max(validation_auc)
points(optimal_iter, validation_auc[optimal_iter], 
       col = "darkred", pch = 19, cex = 1.5)

# Add legend
legend("bottomright",
       legend = c("Training", "Validation", 
                  paste("Best Validation AUC =", 
                        round(validation_auc[optimal_iter], 3))),
       col = c("blue", "darkred", "darkred"),
       lwd = c(2, 2, NA),
       pch = c(NA, NA, 19),
       bg = "white")


#### XGBOOST BASIC TRAINING VS VALIDATION

# Extract cross-validation (CV) results from your XGBoost model
cv_results <- xgboost_cv$evaluation_log

# Create a ggplot visualization showing both training and validation AUC curves
ggplot(cv_results, aes(x = iter)) +
  # Plot Training AUC line (if available in the evaluation log)
  geom_line(aes(y = train_auc_mean, color = "Training")) +
  
  # Plot Validation AUC line
  geom_line(aes(y = test_auc_mean, color = "Validation")) +
  
  # Add plot labels and title
  labs(
    title = "XGBoost Learning Curves",  # Chart title
    x = "Iterations",  # X-axis label representing the number of boosting iterations
    y = "AUC",  # Y-axis label representing AUC (Area Under the Curve) score
    color = "Dataset"  # Legend title indicating dataset type
  ) +
  
  # Set custom colors for training and validation curves
  scale_color_manual(values = c("Training" = "blue", "Validation" = "red")) +
  
  # Apply a minimalistic theme for better visualization
  theme_minimal()
